// Palindrom Possibility Checker

