# INTERVIEW QUESTIONS

## Largest Consecutive Sum of two

## Instructions
Given an array of integers, find the maximum sum of any two consecutive elements

## Example
Test Case 1: [1, 2, 3]  
Expected output: 5

Explanation: `2` and `3` equal the greatest sum of any two consecutive elements

Test Case 2: [18, 7, 1, 2, 20, 9]  
Expected output: 29

Explanation: `20` and `9` equal the greatest sum of any two consecutive elements

## Optimal Time
O(n)